package api

import (
	"html/template"
	"io"
	"testing"
	"time"

	"traefik-cloudflare-manager/lib"
	"traefik-cloudflare-manager/models"
)

func TestTemplatesParse(t *testing.T) {
	_, err := template.New("").Funcs(template.FuncMap{
		"bytes":         lib.FormatBytes,
		"strategyLabel": lib.LoadBalancerStrategyLabel,
	}).ParseFS(templatesFS, "templates/*.tmpl")
	if err != nil {
		t.Fatal(err)
	}
}

func TestDashboardTemplateExecutes(t *testing.T) {
	tpl, err := template.New("").Funcs(template.FuncMap{
		"bytes":         lib.FormatBytes,
		"strategyLabel": lib.LoadBalancerStrategyLabel,
	}).ParseFS(templatesFS, "templates/*.tmpl")
	if err != nil {
		t.Fatal(err)
	}
	view := dashboardView{
		Config: &models.Config{
			Domain:      "example.com",
			Mode:        "internal",
			TraefikHost: "iproxy.example.com",
			ManagerHost: "iproxym.example.com",
			Users: []models.User{{
				Username:  "admin",
				CreatedAt: time.Date(2026, 5, 24, 12, 0, 0, 0, time.UTC),
			}},
			Proxies: []models.ProxyConfig{{
				Host:      "app.example.com",
				Protocol:  "http",
				IP:        "10.0.0.10",
				Port:      8080,
				Status:    "ready",
				CreatedBy: "admin",
			}},
		},
		CurrentUser: "admin",
	}
	if err := tpl.ExecuteTemplate(io.Discard, "dashboard.tmpl", view); err != nil {
		t.Fatal(err)
	}
	if err := tpl.ExecuteTemplate(io.Discard, "users.tmpl", view); err != nil {
		t.Fatal(err)
	}
}
