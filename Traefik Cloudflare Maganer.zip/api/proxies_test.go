package api

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"traefik-cloudflare-manager/models"
)

func TestHandleAPIProxiesEmptyListReturnsArray(t *testing.T) {
	app := NewApp(&models.Store{}, &models.Config{})
	req := httptest.NewRequest(http.MethodGet, "/api/proxies", nil)
	rec := httptest.NewRecorder()

	app.handleAPIProxies(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, rec.Code)
	}
	if got := strings.TrimSpace(rec.Body.String()); got != "[]" {
		t.Fatalf("expected empty JSON array, got %q", got)
	}
}
