package lib

import (
	"context"
	"crypto/tls"
	"fmt"
	"net"
	"strings"
	"time"
)

func CheckHTTPSReady(ctx context.Context, host string) error {
	dialer := &net.Dialer{Timeout: 5 * time.Second}
	conn, err := tls.DialWithDialer(dialer, "tcp", net.JoinHostPort(host, "443"), &tls.Config{
		ServerName:         host,
		InsecureSkipVerify: true,
		MinVersion:         tls.VersionTLS12,
	})
	if err != nil {
		return err
	}
	defer conn.Close()
	select {
	case <-ctx.Done():
		return ctx.Err()
	default:
	}
	state := conn.ConnectionState()
	if len(state.PeerCertificates) == 0 {
		return fmt.Errorf("no certificate was served")
	}
	cert := state.PeerCertificates[0]
	if err := cert.VerifyHostname(host); err != nil {
		return err
	}
	if cert.NotAfter.Before(time.Now()) {
		return fmt.Errorf("certificate is expired")
	}
	if cert.CheckSignatureFrom(cert) == nil && strings.EqualFold(cert.Issuer.String(), cert.Subject.String()) {
		return fmt.Errorf("self-signed certificate is still being served")
	}
	return nil
}

func WaitForHTTPSReady(ctx context.Context, host string, interval time.Duration) error {
	var last error
	for {
		if err := CheckHTTPSReady(ctx, host); err == nil {
			return nil
		} else {
			last = err
		}
		timer := time.NewTimer(interval)
		select {
		case <-ctx.Done():
			timer.Stop()
			if last != nil {
				return last
			}
			return ctx.Err()
		case <-timer.C:
		}
	}
}
