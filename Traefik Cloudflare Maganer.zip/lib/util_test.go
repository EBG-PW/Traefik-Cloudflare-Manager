package lib

import "testing"

func TestIsPrivateIP(t *testing.T) {
	tests := map[string]bool{
		"192.168.1.10": true,
		"10.0.0.4":     true,
		"172.16.1.2":   true,
		"172.32.1.2":   false,
		"8.8.8.8":      false,
	}
	for ip, want := range tests {
		if got := IsPrivateIP(ip); got != want {
			t.Fatalf("IsPrivateIP(%q)=%v want %v", ip, got, want)
		}
	}
}

func TestCleanHost(t *testing.T) {
	got := CleanHost("https://App.Example.com/path")
	if got != "app.example.com" {
		t.Fatalf("CleanHost returned %q", got)
	}
}
