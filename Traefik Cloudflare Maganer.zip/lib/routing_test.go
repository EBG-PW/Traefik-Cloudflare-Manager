package lib

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"traefik-cloudflare-manager/models"
)

func TestRouterName(t *testing.T) {
	got := RouterName("app.example.com")
	if got != "app-example-com" {
		t.Fatalf("RouterName returned %q", got)
	}
}

func TestWriteTraefikConfigLoadBalancerStrategy(t *testing.T) {
	store := &models.Store{DataDir: t.TempDir()}
	cfg := &models.Config{
		TraefikHost:  "proxy.example.com",
		ManagerHost:  "proxym.example.com",
		Username:     "admin",
		PasswordHash: "$2a$04$Dr5cjhhnTwQfKJStL8jjQuGGrkrWPccSSV8r35NrP41nxX0W67Qbe",
		Proxies: []models.ProxyConfig{{
			Host:         "app.example.com",
			LoadBalancer: true,
			Strategy:     "leasttime",
			Sticky:       true,
			Backends: []models.Backend{
				{Protocol: "http", IP: "10.0.0.10", Port: 8080, Weight: 3},
				{Protocol: "http", IP: "10.0.0.11", Port: 8080, Weight: 1},
			},
		}},
	}

	if err := WriteTraefikConfig(store, cfg); err != nil {
		t.Fatal(err)
	}
	raw, err := os.ReadFile(filepath.Join(store.DataDir, "traefik", "config", TraefikConfigFile))
	if err != nil {
		t.Fatal(err)
	}
	got := string(raw)
	for _, want := range []string{"sticky:", "weight: 3", "weight: 1"} {
		if !strings.Contains(got, want) {
			t.Fatalf("expected generated config to contain %q, got:\n%s", want, got)
		}
	}
	if strings.Contains(got, "strategy:") {
		t.Fatalf("did not expect generated config to contain unsupported strategy field, got:\n%s", got)
	}
}
